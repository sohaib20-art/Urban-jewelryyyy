const wilaya=document.getElementById('wilaya'), delivery=document.getElementById('delivery'), summary=document.getElementById('shipping-summary'), addressWrap=document.getElementById('address-wrap'), address=document.getElementById('address');
function updateShipping(){if(!wilaya||!delivery)return;const opt=wilaya.options[wilaya.selectedIndex];if(!opt||!opt.value||!delivery.value){summary.textContent='Choisissez votre wilaya et votre mode de livraison pour voir les frais.';return;}const fee=delivery.value==='home'?opt.dataset.home:opt.dataset.desk;summary.innerHTML=`Frais de livraison estimés : <strong>${fee} DA</strong> <small>· À confirmer avec le transporteur.</small>`;addressWrap.style.display=delivery.value==='home'?'':'none';address.required=delivery.value==='home';}
if(wilaya){wilaya.addEventListener('change',updateShipping);delivery.addEventListener('change',updateShipping);updateShipping();}
function chooseProduct(name){const field=document.getElementById('product-choice');if(field){field.value=name;document.getElementById('items').value=name;document.getElementById('commande').scrollIntoView({behavior:'smooth'});}}
function prepareOrder(){document.getElementById('items').value=document.getElementById('product-choice').value;return true;}

let galleryImages=[], galleryIndex=0;
function openGallery(images,index,title){
  galleryImages=Array.isArray(images)?images:[images];
  galleryIndex=index||0;
  const viewer=document.getElementById('image-viewer');
  document.getElementById('viewer-title').textContent=title||'Urban Jewelry';
  viewer.classList.add('active');
  document.body.classList.add('viewer-open');
  showGalleryImage();
}
function showGalleryImage(){
  if(!galleryImages.length)return;
  document.getElementById('viewer-image').src=galleryImages[galleryIndex];
  document.getElementById('viewer-count').textContent=(galleryIndex+1)+' / '+galleryImages.length;
  document.querySelector('.viewer-prev').style.display=galleryImages.length>1?'grid':'none';
  document.querySelector('.viewer-next').style.display=galleryImages.length>1?'grid':'none';
}
function galleryStep(direction){
  if(!galleryImages.length)return;
  galleryIndex=(galleryIndex+direction+galleryImages.length)%galleryImages.length;
  showGalleryImage();
}
function closeGallery(){
  const viewer=document.getElementById('image-viewer');
  if(viewer)viewer.classList.remove('active');
  document.body.classList.remove('viewer-open');
}
document.addEventListener('keydown',e=>{
  if(e.key==='Escape')closeGallery();
  if(e.key==='ArrowRight')galleryStep(1);
  if(e.key==='ArrowLeft')galleryStep(-1);
});
